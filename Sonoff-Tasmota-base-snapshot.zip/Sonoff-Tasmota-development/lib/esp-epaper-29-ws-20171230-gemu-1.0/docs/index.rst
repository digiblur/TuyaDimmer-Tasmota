ESP-IDF Component Documentation 
===============================

Component: epaper-29-ws
-----------------------

This component and documentation is based almost entirely on `epaper <https://github.com/espressif/esp-iot-solution/tree/master/components/spi_devices/epaper/test>`_ component for another type of display developed by `esp-iot-solution <https://github.com/espressif/esp-iot-solution>`_ team.

.. include:: _build/inc/epaper-29-ws.inc
